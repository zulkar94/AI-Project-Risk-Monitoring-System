# AI Project Risk Monitoring System

Continuously scores project risk from cost, schedule, task-completion, and
resource signals, and surfaces it on a live dashboard:
**Risk → Impact → Probability → Mitigation → Trend**.

Built as an MBA Project Management capstone piece — pairs a quantitative
scoring model with qualitative mitigation guidance and a working tool.

## Features

- Weighted, configurable composite risk score (0-100) per project
- Live-tunable weights in the dashboard sidebar
- Risk register ranked by Impact x Probability
- Trend detection (Rising / Stable / Falling) across refresh cycles
- Pluggable data layer — swap the CSV loader for Jira/MS Project/ERP later
- Unit-tested scoring engine

## Project structure

```
ai-project-risk-monitor/
├── app.py                     # Streamlit dashboard entry point
├── src/
│   ├── models.py               # Project, RiskItem, and snapshot dataclasses
│   ├── risk_engine.py           # Scoring, normalization, ranking, trend logic
│   └── data_loader.py           # CSV -> Project objects (swap for a live connector)
├── data/
│   └── sample_projects.csv      # 5 sample projects with cost/schedule/task/resource data
├── tests/
│   └── test_risk_engine.py      # pytest suite for the scoring engine
├── docs/
│   └── METHODOLOGY.md           # Full scoring formula and thresholds
├── requirements.txt
├── LICENSE
└── .gitignore
```

## Quickstart

```bash
git clone https://github.com/<your-username>/ai-project-risk-monitor.git
cd ai-project-risk-monitor
python -m venv .venv && source .venv/bin/activate   # optional but recommended
pip install -r requirements.txt

streamlit run app.py
```

Open the URL Streamlit prints (usually http://localhost:8501).

## Run tests

```bash
pip install -r requirements.txt
python -m pytest tests/ -v
```

## How scoring works (short version)

1. Each project reports four snapshots: **Cost** (budget vs actual), **Schedule**
   (critical-path slip), **Tasks** (% complete vs % time elapsed), **Resources**
   (utilization + unfilled critical roles).
2. Each signal is normalized to a 0-100 sub-score against warn/high thresholds.
3. Sub-scores are combined with configurable weights into one composite score.
4. Composite score drives **Impact** (High/Medium/Low bucket) and **Probability**
   (the score itself, 0-100%).
5. **Trend** compares the current score to the prior scoring cycle.
6. Risks are ranked by Impact x Probability so the worst items surface first.

Full formula and default thresholds: [`docs/METHODOLOGY.md`](docs/METHODOLOGY.md).

## Using your own data

Replace `data/sample_projects.csv` with your own rows (same columns), or
write a new loader in `src/data_loader.py` that returns a list of
`Project` objects — e.g. pulling from the Jira API, an MS Project export,
or a warehouse table. The engine and dashboard don't need to change.

## Publishing to GitHub

```bash
cd ai-project-risk-monitor
git init
git add .
git commit -m "Initial commit: AI Project Risk Monitoring System"
git branch -M main
git remote add origin https://github.com/<your-username>/ai-project-risk-monitor.git
git push -u origin main
```

## License

MIT — see [LICENSE](LICENSE).
