# Scoring Methodology

## Inputs (per project, per refresh cycle)

| Dimension | Signal | Source in this repo |
|---|---|---|
| Cost | `variance_pct = (actual_cost - planned_budget) / planned_budget * 100` | `CostSnapshot` |
| Schedule | `critical_path_slip_days` (positive = behind) | `ScheduleSnapshot` |
| Tasks | `completion_gap = pct_time_elapsed - pct_complete` (positive = behind) | `TaskSnapshot` |
| Resources | `avg_utilization_pct` + `unfilled_roles` penalty | `ResourceSnapshot` |

## Normalization

Each raw signal is mapped onto a 0-100 sub-score using a warn/high threshold pair:

```
value <= warn        -> 0-40  (linear)
warn < value < high   -> 40-100 (linear)
value >= high         -> 100
```

Default thresholds (tune in `RiskEngineConfig`):

- Cost variance: warn 10%, high 20%
- Schedule slip: warn 5 days, high 15 days
- Task completion gap: warn 10 pts, high 20 pts
- Resource utilization: warn 90%, high 100% (+5 pts per unfilled critical role, capped at +20)

## Composite score

```
composite = Σ(sub_score_i * weight_i) / Σ(weight_i)
```

Default weights: Cost 0.30, Schedule 0.30, Tasks 0.25, Resources 0.15 — configurable per
organization, exposed live in the dashboard sidebar.

## Impact bucketing

- **High**: composite >= 66
- **Medium**: composite >= 33
- **Low**: composite < 33

## Probability

The composite score itself is used as the probability-of-realization estimate (0-100%).
This is a simplification appropriate for an MBA-level capstone; a production system would
calibrate probability against historical realized-risk data (logistic regression or similar)
rather than reusing the composite score directly.

## Trend

Each project keeps a rolling history of composite scores. Trend compares the two most
recent scores:

- `Rising` if the latest score is more than 3 points above the prior one
- `Falling` if more than 3 points below
- `Stable` otherwise

## Ranking

The dashboard sorts risks by `Impact_weight x Probability`, where Impact_weight is
High=3, Medium=2, Low=1 — surfacing the risks that combine severity and likelihood.

## Extending this model

- Swap `src/data_loader.py` for a live connector (Jira, MS Project, SAP, Smartsheet, etc.)
- Add a persistence layer (e.g. SQLite/Postgres) to store snapshot history instead of
  the in-memory `_history` dict, so trend survives process restarts.
- Replace the linear normalization with a fitted risk model once enough historical
  realized-risk outcomes are available.
