import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.models import (
    Project,
    CostSnapshot,
    ScheduleSnapshot,
    TaskSnapshot,
    ResourceSnapshot,
    RiskCategory,
    Severity,
    Trend,
)
from src.risk_engine import RiskEngine, RiskEngineConfig


def make_project(**overrides) -> Project:
    defaults = dict(
        project_id="TEST-1",
        name="Test Project",
        cost=CostSnapshot(date.today(), planned_budget=100000, actual_cost=100000),
        schedule=ScheduleSnapshot(date.today(), planned_pct_elapsed=50, critical_path_slip_days=0),
        tasks=TaskSnapshot(date.today(), pct_complete=50, pct_time_elapsed=50),
        resources=ResourceSnapshot(date.today(), avg_utilization_pct=80, unfilled_roles=0),
    )
    defaults.update(overrides)
    return Project(**defaults)


def test_healthy_project_scores_low():
    engine = RiskEngine()
    project = make_project()
    score = engine.score_project(project)
    assert score < 33, f"expected low risk score, got {score}"


def test_over_budget_and_slipped_schedule_scores_high():
    engine = RiskEngine()
    project = make_project(
        cost=CostSnapshot(date.today(), planned_budget=100000, actual_cost=140000),
        schedule=ScheduleSnapshot(date.today(), planned_pct_elapsed=50, critical_path_slip_days=25),
    )
    score = engine.score_project(project)
    assert score >= 60, f"expected high risk score, got {score}"


def test_score_to_impact_buckets():
    assert RiskEngine.score_to_impact(10) == Severity.LOW
    assert RiskEngine.score_to_impact(50) == Severity.MEDIUM
    assert RiskEngine.score_to_impact(80) == Severity.HIGH


def test_trend_detection_rising():
    engine = RiskEngine()
    project = make_project(cost=CostSnapshot(date.today(), 100000, 100000))
    engine.score_project(project)  # first pass, low
    project.cost = CostSnapshot(date.today(), planned_budget=100000, actual_cost=150000)
    engine.score_project(project)  # second pass, much higher
    assert engine.trend_for(project.project_id) == Trend.RISING


def test_build_risk_item_shape():
    engine = RiskEngine()
    project = make_project()
    item = engine.build_risk_item(
        project=project,
        category=RiskCategory.COST,
        name="Cost Risk",
        mitigation="Reforecast budget",
        owner="Finance Lead",
    )
    assert item.risk_id == "TEST-1-COS"
    assert 0 <= item.probability_pct <= 100
    assert item.impact in (Severity.LOW, Severity.MEDIUM, Severity.HIGH)


def test_rank_orders_by_impact_times_probability():
    engine = RiskEngine()
    low = make_project(project_id="LOW")
    high = make_project(
        project_id="HIGH",
        cost=CostSnapshot(date.today(), planned_budget=100000, actual_cost=140000),
        schedule=ScheduleSnapshot(date.today(), planned_pct_elapsed=50, critical_path_slip_days=25),
    )
    items = [
        engine.build_risk_item(low, RiskCategory.COST, "Low Risk", "n/a", "n/a"),
        engine.build_risk_item(high, RiskCategory.COST, "High Risk", "n/a", "n/a"),
    ]
    ranked = engine.rank(items)
    assert ranked[0].name == "High Risk"


def test_missing_dimensions_do_not_crash():
    engine = RiskEngine()
    project = Project(project_id="P-EMPTY", name="No Data Yet")
    score = engine.score_project(project)
    assert score == 0.0
