"""
Core data models for the AI Project Risk Monitoring System.
"""

from dataclasses import dataclass, field
from datetime import date
from enum import Enum
from typing import Optional


class RiskCategory(str, Enum):
    COST = "Cost"
    SCHEDULE = "Schedule"
    RESOURCE = "Resource"
    SCOPE = "Scope"


class Severity(str, Enum):
    LOW = "Low"
    MEDIUM = "Medium"
    HIGH = "High"


class Trend(str, Enum):
    RISING = "Rising"
    STABLE = "Stable"
    FALLING = "Falling"


@dataclass
class CostSnapshot:
    """Planned vs actual spend on the date of the snapshot."""
    snapshot_date: date
    planned_budget: float
    actual_cost: float

    @property
    def variance_pct(self) -> float:
        if self.planned_budget == 0:
            return 0.0
        return (self.actual_cost - self.planned_budget) / self.planned_budget * 100


@dataclass
class ScheduleSnapshot:
    """Planned vs actual progress along the timeline."""
    snapshot_date: date
    planned_pct_elapsed: float   # % of total schedule time that should have passed
    critical_path_slip_days: int  # positive = behind schedule


@dataclass
class TaskSnapshot:
    """Task completion vs time elapsed."""
    snapshot_date: date
    pct_complete: float          # actual % of tasks marked done
    pct_time_elapsed: float      # % of project timeline elapsed

    @property
    def completion_gap(self) -> float:
        """Positive = behind, negative = ahead."""
        return self.pct_time_elapsed - self.pct_complete


@dataclass
class ResourceSnapshot:
    """Resource loading snapshot."""
    snapshot_date: date
    avg_utilization_pct: float   # team average utilization, 100 = fully loaded
    unfilled_roles: int          # open/unstaffed critical roles


@dataclass
class RiskItem:
    """A single row in the risk register / dashboard."""
    risk_id: str
    name: str
    category: RiskCategory
    impact: Severity
    probability_pct: float       # 0-100
    mitigation: str
    owner: str
    trend: Trend = Trend.STABLE
    score: float = field(default=0.0)  # impact x probability, computed by engine

    def as_row(self) -> dict:
        return {
            "Risk ID": self.risk_id,
            "Risk": self.name,
            "Category": self.category.value,
            "Impact": self.impact.value,
            "Probability (%)": round(self.probability_pct, 1),
            "Score": round(self.score, 1),
            "Trend": self.trend.value,
            "Mitigation": self.mitigation,
            "Owner": self.owner,
        }


@dataclass
class Project:
    """A monitored project, holding its latest snapshots."""
    project_id: str
    name: str
    cost: Optional[CostSnapshot] = None
    schedule: Optional[ScheduleSnapshot] = None
    tasks: Optional[TaskSnapshot] = None
    resources: Optional[ResourceSnapshot] = None
