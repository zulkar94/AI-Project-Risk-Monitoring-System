"""
Loads project snapshot data from CSV (data/sample_projects.csv) into
Project objects the risk engine can score. Swap this module for a real
connector (Jira, MS Project, ERP export, etc.) without touching the engine.
"""

import csv
from datetime import datetime
from pathlib import Path
from typing import List

from .models import (
    Project,
    CostSnapshot,
    ScheduleSnapshot,
    TaskSnapshot,
    ResourceSnapshot,
)

DATA_DIR = Path(__file__).resolve().parent.parent / "data"


def load_projects(csv_path: Path = None) -> List[Project]:
    csv_path = csv_path or DATA_DIR / "sample_projects.csv"
    projects = []
    with open(csv_path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            snap_date = datetime.strptime(row["snapshot_date"], "%Y-%m-%d").date()
            projects.append(
                Project(
                    project_id=row["project_id"],
                    name=row["name"],
                    cost=CostSnapshot(
                        snapshot_date=snap_date,
                        planned_budget=float(row["planned_budget"]),
                        actual_cost=float(row["actual_cost"]),
                    ),
                    schedule=ScheduleSnapshot(
                        snapshot_date=snap_date,
                        planned_pct_elapsed=float(row["planned_pct_elapsed"]),
                        critical_path_slip_days=int(row["critical_path_slip_days"]),
                    ),
                    tasks=TaskSnapshot(
                        snapshot_date=snap_date,
                        pct_complete=float(row["pct_complete"]),
                        pct_time_elapsed=float(row["pct_time_elapsed"]),
                    ),
                    resources=ResourceSnapshot(
                        snapshot_date=snap_date,
                        avg_utilization_pct=float(row["avg_utilization_pct"]),
                        unfilled_roles=int(row["unfilled_roles"]),
                    ),
                )
            )
    return projects
