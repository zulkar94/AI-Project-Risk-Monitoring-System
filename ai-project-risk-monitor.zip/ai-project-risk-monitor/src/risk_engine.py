"""
Risk scoring engine.

Continuously converts cost, schedule, task-completion and resource signals
into a weighted risk score per project, then classifies impact/probability
and derives a register of RiskItems for the dashboard.

Weighting is configurable via RiskEngineConfig so it can be tuned per
organization without touching scoring logic.
"""

from dataclasses import dataclass
from typing import Dict, List, Optional

from .models import (
    Project,
    RiskItem,
    RiskCategory,
    Severity,
    Trend,
)


@dataclass
class RiskEngineConfig:
    # Relative weight of each dimension in the composite score (should sum to 1.0)
    weight_cost: float = 0.30
    weight_schedule: float = 0.30
    weight_tasks: float = 0.25
    weight_resources: float = 0.15

    # Thresholds that flag a dimension as breached (used for Impact/Probability)
    cost_variance_warn_pct: float = 10.0
    cost_variance_high_pct: float = 20.0

    schedule_slip_warn_days: int = 5
    schedule_slip_high_days: int = 15

    task_gap_warn_pct: float = 10.0
    task_gap_high_pct: float = 20.0

    resource_util_warn_pct: float = 90.0
    resource_util_high_pct: float = 100.0


def _normalize(value: float, warn: float, high: float) -> float:
    """
    Map a raw metric onto a 0-100 sub-score.
    0   -> at/under warn threshold
    100 -> at/over high threshold
    Linear in between. Values below 0 are clamped to 0.
    """
    if value <= warn:
        return max(0.0, (value / warn) * 40) if warn > 0 else 0.0
    if value >= high:
        return 100.0
    span = high - warn
    return 40 + (value - warn) / span * 60


class RiskEngine:
    def __init__(self, config: Optional[RiskEngineConfig] = None):
        self.config = config or RiskEngineConfig()
        self._history: Dict[str, List[float]] = {}  # project_id -> past composite scores

    def score_project(self, project: Project) -> float:
        """Return a 0-100 composite risk score for a single project."""
        cfg = self.config
        sub_scores = []
        weights = []

        if project.cost:
            sub_scores.append(
                _normalize(abs(project.cost.variance_pct), cfg.cost_variance_warn_pct, cfg.cost_variance_high_pct)
            )
            weights.append(cfg.weight_cost)

        if project.schedule:
            sub_scores.append(
                _normalize(
                    max(0, project.schedule.critical_path_slip_days),
                    cfg.schedule_slip_warn_days,
                    cfg.schedule_slip_high_days,
                )
            )
            weights.append(cfg.weight_schedule)

        if project.tasks:
            sub_scores.append(
                _normalize(max(0, project.tasks.completion_gap), cfg.task_gap_warn_pct, cfg.task_gap_high_pct)
            )
            weights.append(cfg.weight_tasks)

        if project.resources:
            sub_scores.append(
                _normalize(
                    project.resources.avg_utilization_pct,
                    cfg.resource_util_warn_pct,
                    cfg.resource_util_high_pct,
                )
                + min(project.resources.unfilled_roles * 5, 20)  # extra penalty per open critical role
            )
            weights.append(cfg.weight_resources)

        if not sub_scores:
            return 0.0

        total_weight = sum(weights)
        composite = sum(s * w for s, w in zip(sub_scores, weights)) / total_weight
        composite = min(composite, 100.0)

        self._history.setdefault(project.project_id, []).append(composite)
        return composite

    def trend_for(self, project_id: str) -> Trend:
        """Compare the last two recorded scores to derive a trend arrow."""
        hist = self._history.get(project_id, [])
        if len(hist) < 2:
            return Trend.STABLE
        delta = hist[-1] - hist[-2]
        if delta > 3:
            return Trend.RISING
        if delta < -3:
            return Trend.FALLING
        return Trend.STABLE

    @staticmethod
    def score_to_impact(score: float) -> Severity:
        if score >= 66:
            return Severity.HIGH
        if score >= 33:
            return Severity.MEDIUM
        return Severity.LOW

    def build_risk_item(
        self,
        project: Project,
        category: RiskCategory,
        name: str,
        mitigation: str,
        owner: str,
    ) -> RiskItem:
        """Convenience factory: score the project and wrap the result as a RiskItem."""
        composite = self.score_project(project)
        impact = self.score_to_impact(composite)
        item = RiskItem(
            risk_id=f"{project.project_id}-{category.value[:3].upper()}",
            name=name,
            category=category,
            impact=impact,
            probability_pct=composite,
            mitigation=mitigation,
            owner=owner,
            trend=self.trend_for(project.project_id),
            score=composite,
        )
        return item

    @staticmethod
    def rank(items: List[RiskItem]) -> List[RiskItem]:
        """Sort risks by Impact x Probability, highest first."""
        impact_weight = {Severity.HIGH: 3, Severity.MEDIUM: 2, Severity.LOW: 1}
        return sorted(
            items,
            key=lambda r: impact_weight[r.impact] * r.probability_pct,
            reverse=True,
        )
