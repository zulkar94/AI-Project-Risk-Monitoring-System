"""
AI Project Risk Monitoring System — Streamlit dashboard.

Run: streamlit run app.py

Shows Risk -> Impact -> Probability -> Mitigation -> Trend, continuously
recomputed from cost, schedule, task-completion, and resource inputs.
"""

import pandas as pd
import streamlit as st

from src.data_loader import load_projects
from src.risk_engine import RiskEngine, RiskEngineConfig
from src.models import RiskCategory

st.set_page_config(page_title="AI Project Risk Monitor", layout="wide")

# ---- Sidebar: tunable weights (lets a PM re-weight the model live) ----
st.sidebar.header("Scoring Weights")
w_cost = st.sidebar.slider("Cost", 0.0, 1.0, 0.30, 0.05)
w_sched = st.sidebar.slider("Schedule", 0.0, 1.0, 0.30, 0.05)
w_tasks = st.sidebar.slider("Tasks", 0.0, 1.0, 0.25, 0.05)
w_res = st.sidebar.slider("Resources", 0.0, 1.0, 0.15, 0.05)

total = w_cost + w_sched + w_tasks + w_res or 1.0
config = RiskEngineConfig(
    weight_cost=w_cost / total,
    weight_schedule=w_sched / total,
    weight_tasks=w_tasks / total,
    weight_resources=w_res / total,
)
engine = RiskEngine(config)

st.title("AI Project Risk Monitoring System")
st.caption("Cost + Schedule + Task Completion + Resources -> continuously updated project risk.")

projects = load_projects()

MITIGATIONS = {
    RiskCategory.COST: "Reforecast budget; review change orders; escalate variance >10% to sponsor.",
    RiskCategory.SCHEDULE: "Compress critical path; add resources to lagging stream; replan milestones.",
    RiskCategory.RESOURCE: "Backfill open roles; rebalance load; flag burnout risk to resourcing lead.",
}
OWNERS = {
    RiskCategory.COST: "Finance Lead",
    RiskCategory.SCHEDULE: "Program Manager",
    RiskCategory.RESOURCE: "Resource Manager",
}

rows = []
for p in projects:
    # Run twice so the trend arrow has two data points on first load (demo only;
    # in production the second call happens on the next real refresh cycle).
    engine.score_project(p)
    for category in (RiskCategory.COST, RiskCategory.SCHEDULE, RiskCategory.RESOURCE):
        item = engine.build_risk_item(
            project=p,
            category=category,
            name=f"{p.name} — {category.value} Risk",
            mitigation=MITIGATIONS[category],
            owner=OWNERS[category],
        )
        rows.append(item)

ranked = engine.rank(rows)
df = pd.DataFrame([r.as_row() for r in ranked])

# ---- KPI row ----
col1, col2, col3 = st.columns(3)
col1.metric("Projects Monitored", len(projects))
col2.metric("High-Impact Risks", int((df["Impact"] == "High").sum()))
col3.metric("Avg Risk Score", f"{df['Score'].mean():.1f}")

st.divider()

# ---- Dashboard table: Risk -> Impact -> Probability -> Mitigation -> Trend ----
st.subheader("Risk Register")


def _trend_arrow(t: str) -> str:
    return {"Rising": "▲ Rising", "Stable": "→ Stable", "Falling": "▼ Falling"}.get(t, t)


display_df = df.copy()
display_df["Trend"] = display_df["Trend"].apply(_trend_arrow)
st.dataframe(
    display_df[["Risk", "Category", "Impact", "Probability (%)", "Trend", "Mitigation", "Owner"]],
    use_container_width=True,
    hide_index=True,
)

st.divider()
st.subheader("Risk Score by Project")
chart_df = df.groupby("Risk")["Score"].max().sort_values(ascending=False)
st.bar_chart(chart_df)

with st.expander("How the score is computed"):
    st.markdown(
        """
        Each project's cost variance, schedule slip, task-completion gap, and
        resource overallocation are normalized to a 0-100 sub-score against
        configurable warn/high thresholds, then combined using the sidebar
        weights into one composite risk score. Impact is bucketed from that
        score (High >= 66, Medium >= 33, Low below), Probability is the score
        itself, and Trend compares the current run to the prior one.
        See `docs/METHODOLOGY.md` for the full formula.
        """
    )
